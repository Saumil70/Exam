﻿
using Exam.Models;
using Exam.Repository.IRepository;
using Exam.StudentViewModel;
using System;
using System.Linq;
using System.Web.Helpers;
using System.Web.Mvc;


namespace UserDetailsPopup.Controllers
{
    public class StudentManagerController : Controller
    {
        
        private readonly IUnitOfWork _unitOfWork;

        public StudentManagerController(IUnitOfWork db)
        {
            _unitOfWork = db;
         
        }

        public ActionResult Index()
        {
            return View();
        }

        public JsonResult StudentList()
        {
            var data = _unitOfWork.StudentRepository.GetAll(includeProperties: "Cities,States,Country,ContactInfo")
                        .Select(s => new
                        {
                            s.StudentId,
                            s.FirstName,
                            s.LastName,
                            Age = CalculateAge(s.DOB),
                            s.Salary,
                            StartingDate= s.StartingDate.ToString("yyyy-MM-dd"),
                            s.Position,
                            s.IsActive,
                            s.CountryId,
                            s.StateId,
                            s.CityId,
                            s.ContactInfo.Email,
                            s.ContactInfo.PhoneNumber,
                            s.Country.CountryName,
                            s.States.StateName,
                            s.Cities.CityName
                        }).ToList();



            return Json(data, JsonRequestBehavior.AllowGet);
        }

        private int CalculateAge(DateTime dob)
        {
            DateTime currentDate = DateTime.Today;
            int age = currentDate.Year - dob.Year;
            if (dob > currentDate.AddYears(-age)) // Check if the birthday has occurred this year
            {
                age--;
            }
            return age;
        }

        public JsonResult CountryList()
        {
            var data = _unitOfWork.CountryRepository.GetAll().ToList();
            return Json(data,JsonRequestBehavior.AllowGet);

        }
        public JsonResult StateList(int countryId)
        {
            var data = _unitOfWork.StateRepository.GetAll().Where(u => u.CountryId == countryId);
            return Json(data,JsonRequestBehavior.AllowGet); // Return states as JSON

        }
        public JsonResult CityList(int stateId)
        {
            var data = _unitOfWork.CityRepository.GetAll().Where(u => u.StateId == stateId);
            return Json(data,JsonRequestBehavior.AllowGet); // Return states as JSON

        }


        [HttpPost]
        public JsonResult AddStudent(StudentViewModel studentViewModel)
        {
            if(ModelState.IsValid)
            {
                var contactInfo = new ContactInfo
                {
                    PhoneNumber = studentViewModel.PhoneNumber,
                    Email = studentViewModel.Email,
                };
                var student = new Student
                {
                    FirstName = studentViewModel.FirstName,
                    LastName = studentViewModel.LastName,
                    DOB = studentViewModel.DOB,
                    Salary = studentViewModel.Salary,
                    StartingDate = studentViewModel.StartingDate,
                    Position = studentViewModel.Position,
                    IsActive = true,
                    CountryId = studentViewModel.CountryId,
                    CityId = studentViewModel.CityId,
                    StateId = studentViewModel.StateId,
                    
                };
                _unitOfWork.StudentRepository.Add(student);
                _unitOfWork.ContactInfoRepository.Add(contactInfo);
                _unitOfWork.Save();
                return Json(new { success = true });

            }
            else
            {
                return Json(new { success = false });

            }

        }
        public JsonResult Edit(int id)
        {
            var data = _unitOfWork.StudentRepository.GetAll(
                filter: s => s.StudentId == id,
                includeProperties: "Cities,States,Country,ContactInfo")
            .Select(s => new
            {
                s.StudentId,
                s.FirstName,
                s.LastName,
                s.Salary,
                StartingDate = s.StartingDate.ToString("yyyy-MM-dd"),
                DOB = s.DOB.ToString("dd-MM-yyyy"),
                s.Position,
                s.IsActive,
                s.CountryId,
                s.StateId,
                s.CityId,
                s.ContactInfoId,
                s.ContactInfo.Email,
                s.ContactInfo.PhoneNumber,
                s.Country.CountryName,
                s.States.StateName,
                s.Cities.CityName
            })
            .FirstOrDefault();

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult EditStudent(StudentViewModel studentViewModel)
        {
            if (ModelState.IsValid)
            {
                var existingStudent = _unitOfWork.StudentRepository.Get(
                    filter: s => s.StudentId == studentViewModel.StudentId, // Assuming StudentId is the primary key
                    includeProperties: "ContactInfo",
                    tracked: true // Track changes for updating
                );
                if (existingStudent != null)
                {
                    existingStudent.FirstName = studentViewModel.FirstName;
                    existingStudent.LastName = studentViewModel.LastName;
                    existingStudent.DOB = studentViewModel.DOB;
                    existingStudent.Salary = studentViewModel.Salary;
                    existingStudent.StartingDate = studentViewModel.StartingDate;
                    existingStudent.Position = studentViewModel.Position;
                    existingStudent.IsActive = true; // You can update IsActive if necessary
                    existingStudent.CountryId = studentViewModel.CountryId;
                    existingStudent.CityId = studentViewModel.CityId;
                    existingStudent.StateId = studentViewModel.StateId;

                    // Update the properties of the contactInfo entity
                    existingStudent.ContactInfo.PhoneNumber = studentViewModel.PhoneNumber;
                    existingStudent.ContactInfo.Email = studentViewModel.Email;


                    
                    _unitOfWork.Save();
                    
                }
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false });
            }
            
        }

        public JsonResult Delete(int[] ids)
        {
            foreach (int id in ids)
            {
                var student = _unitOfWork.StudentRepository.Get(c => c.StudentId == id);
                if (student != null)
                {
                    _unitOfWork.StudentRepository.Remove(student);
                }
            }
            _unitOfWork.Save();
            return Json("Selected users deleted successfully");
        }

    }
}
