﻿using Exam.Models;
using Exam.Repository;
using Exam.Repository.IRepository;

namespace UserDetails.Repository
{
    public class StudentRepository : Repository<Student>, IStudentRepository
    {
        private StudentEntites _db;
        public StudentRepository(StudentEntites db) : base(db)
        {
            _db = db;
        }
        public void Update(Student obj)
        {
            Update(obj);
        }


    }
}
